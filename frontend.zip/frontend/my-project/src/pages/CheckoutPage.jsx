import React from "react";
export default function CheckoutPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Checkout</h2>
      <p>Checkout functionality coming soon.</p>
    </div>
  );
}