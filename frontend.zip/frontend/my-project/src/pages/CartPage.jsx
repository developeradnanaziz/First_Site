import React from "react";

export default function CartPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
      <p>Your cart is empty.</p>
    </div>
  );
}