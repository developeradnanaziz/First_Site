import React, { useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/firebaseConfig';

const TrackShipment = () => {
  const [trackingId, setTrackingId] = useState('');
  const [shipment, setShipment] = useState(null);
  const [error, setError] = useState('');

  const handleTrack = async () => {
    try {
      const docRef = doc(db, 'shipments', trackingId.trim());
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        setShipment(docSnap.data());
        setError('');
      } else {
        setShipment(null);
        setError('Shipment not found. Please check the tracking ID.');
      }
    } catch (err) {
      console.error(err);
      setError('Something went wrong while tracking shipment.');
    }
  };

  const getProgressValue = (status) => {
    switch (status) {
      case 'Pending':
        return 25;
      case 'In Transit':
        return 60;
      case 'Delivered':
        return 100;
      default:
        return 0;
    }
  };

  return (
    <div className="max-w-xl mx-auto p-6 mt-10 bg-white rounded-xl shadow">
      <h2 className="text-2xl font-bold mb-4 text-center">📦 Track Your Shipment</h2>

      <div className="flex gap-3 mb-4">
        <input
          type="text"
          placeholder="Enter Tracking ID"
          className="flex-1 p-3 border border-gray-300 rounded focus:outline-none"
          value={trackingId}
          onChange={(e) => setTrackingId(e.target.value)}
        />
        <button
          onClick={handleTrack}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Track
        </button>
      </div>

      {error && <p className="text-red-500">{error}</p>}

      {shipment && (
        <div className="mt-6 border-t pt-4">
          <p><strong>Sender:</strong> {shipment.sender}</p>
          <p><strong>Receiver:</strong> {shipment.receiver}</p>
          <p><strong>Address:</strong> {shipment.address}</p>
          <p><strong>Status:</strong> {shipment.status}</p>
          <p><strong>Package Size:</strong> {shipment.packageSize}</p>
          <div className="mt-4">
            <label className="block mb-1 font-medium">Progress:</label>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div
                className={`bg-green-500 h-4 rounded-full`}
                style={{ width: `${getProgressValue(shipment.status)}%` }}
              ></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TrackShipment;
