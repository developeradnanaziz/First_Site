import React from "react";
export default function UserProfile() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">User Profile</h2>
      <p>User profile info coming soon.</p>
    </div>
  );
}