import React from "react";
export default function Cart() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Cart</h2>
      <p>Cart details coming soon.</p>
    </div>
  );
}