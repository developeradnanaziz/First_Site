import React from "react";
export default function ShipmentTracking() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Shipment Tracking</h2>
      <p>Tracking info coming soon.</p>
    </div>
  );
}