import React from "react";
export default function Checkout() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Checkout</h2>
      <p>Checkout details coming soon.</p>
    </div>
  );
}