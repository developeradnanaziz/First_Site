import React from "react";
export default function ShipmentForm() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">New Shipment</h2>
      <p>Shipment form coming soon.</p>
    </div>
  );
}